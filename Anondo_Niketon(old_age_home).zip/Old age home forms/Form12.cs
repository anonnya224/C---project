﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace Old_age_home_forms
{
    public partial class Form12 : Form
    {
        private string cs = ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
           MaximizeBox = false;
            try
            {
                SqlConnection con = new SqlConnection(cs);
                con.Open();
                Form7 f7 = new Form7();
              
                SqlCommand cmd = new SqlCommand("select * from Client_Details where nid=@nid", con);
                
                cmd.Parameters.AddWithValue("@nid", Form7.nid);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                    {

                        textBox1.Text = Convert.ToString(dr.GetValue(0));
                        textBox2.Text = Convert.ToString(dr.GetValue(1));
                        textBox3.Text = Convert.ToString(dr.GetValue(2));
                        textBox4.Text = Convert.ToString(dr.GetValue(3));
                        textBox5.Text = Convert.ToString(dr.GetValue(4));
                        textBox6.Text = Convert.ToString(dr.GetValue(5));
                        textBox7.Text = Convert.ToString(dr.GetValue(6));
                        byte[] img = (byte[])(dr.GetValue(7));
                        if (img == null)
                        {
                            pictureBox1.Image = null;
                        }
                        else
                        {
                            MemoryStream ms = new MemoryStream(img);
                            pictureBox1.Image = Image.FromStream(ms);
                        }
                    }
                    dr.Close();
                }
                con.Close();
            }
            catch (Exception)
            {
                
                throw;
            }
            }
        


        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void Form12_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
        private byte[] SavePhoto()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
           
            open.Filter = "Image Files(*.jpg; *.jpeg; *.png;)|*.jpg; *.jpeg; *.png;";
            if (open.ShowDialog() == DialogResult.OK)
            {
             
                pictureBox1.Image = new Bitmap(open.FileName);
            }
        }
     private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
                string query = "update Client_Details set name=@name,gender=@gender,age=@age,nid=@nid,contact_no=@contact_no,address=@address,password=@password,picture=@pic where nid=@nid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@gender", textBox2.Text);
                cmd.Parameters.AddWithValue("@age", textBox3.Text);
                cmd.Parameters.AddWithValue("@nid", textBox4.Text);
                cmd.Parameters.AddWithValue("@contact_no", textBox5.Text);
                cmd.Parameters.AddWithValue("@address", textBox6.Text);
                cmd.Parameters.AddWithValue("@password", textBox7.Text);
                cmd.Parameters.AddWithValue("@pic", SavePhoto());

                con.Open();
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    MessageBox.Show("Data Updated Successfully");


                }
                else
                {
                    MessageBox.Show("Data Not Updated");
                }
                
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form26 f26 = new Form26();
            f26.Show();
        }
    }
}
