﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace Old_age_home_forms
{
    public partial class Form16 : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;
       

        public Form16()
        {
            InitializeComponent();
            BindGridView();
            ResetControl();
        }

        private void button3_Click(object sender, EventArgs e)
        {
                SqlConnection con = new SqlConnection(cs);
                string query = "delete from Doctor_Details where nid=@nid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nid", textBox2.Text);

            con.Open();
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    MessageBox.Show("Data deleted Successfully");
                    BindGridView();

                }
                else
                {
                    MessageBox.Show("Data not deleted"); 
                }
        }

         private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 f9 = new Form9();
            f9.Show();

        }

         private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "update Doctor_Details set name=@name,gender=@gender,age=@age,nid=@nid,contact_no=@contact_no,address=@address,specialist_in=@specialist_in,appoinment_time=@appoinment_time,password=@password,picture=@pic where nid=@nid";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@gender", comboBox3.SelectedItem);
            cmd.Parameters.AddWithValue("@age", numericUpDown2.Value);
            cmd.Parameters.AddWithValue("@nid", textBox2.Text);
            cmd.Parameters.AddWithValue("@contact_no", textBox3.Text);
            cmd.Parameters.AddWithValue("@address", textBox4.Text);
            cmd.Parameters.AddWithValue("@specialist_in", comboBox2.SelectedItem);
            cmd.Parameters.AddWithValue("@appoinment_time", textBox5.Text);
            cmd.Parameters.AddWithValue("@password", textBox6.Text);
            cmd.Parameters.AddWithValue("@pic", SavePhoto());

            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Data Updated Successfully");
                BindGridView();
                
            }
            else
            {
                MessageBox.Show("Data Not Updated");
            }
               ResetControl();
        }

        private byte[] SavePhoto()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }
        private Image GetPhoto(byte[] photo)
        {
            MemoryStream ms = new MemoryStream(photo);
            return Image.FromStream(ms);
        }
            private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form23 f23 = new Form23();
            f23.Show();
        }

        void BindGridView()
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "select * from Doctor_Details ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;

            DataGridViewImageColumn dgv = new DataGridViewImageColumn();
            dgv = (DataGridViewImageColumn)dataGridView1.Columns[9];
            dgv.ImageLayout = DataGridViewImageCellLayout.Stretch;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.RowTemplate.Height = 80;
        }
        void ResetControl()
        {
            textBox1.Clear();
            comboBox3.SelectedItem = null;
            numericUpDown2.Value = 0;
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox2.SelectedItem = null;
           
            
            pictureBox1.Image = Properties.Resources.empty_pic;

        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            comboBox3.SelectedItem = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            numericUpDown2.Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value);
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            comboBox2.SelectedItem = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            pictureBox1.Image = GetPhoto((byte[])dataGridView1.SelectedRows[0].Cells[9].Value);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Image";
            ofd.Filter = "ALL IMAGE FILE (*.*) | *.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 f9 = new Form9();
            f9.Show();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
        }
    }
}
     



