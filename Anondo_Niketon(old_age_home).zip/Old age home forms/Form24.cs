﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Old_age_home_forms
{
    public partial class Form24 : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;
        public Form24()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            {
                SqlConnection con = new SqlConnection(cs);
                string query = "insert into Client_Appoinment values (@name,@age,@problem)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", textBox4.Text);
                cmd.Parameters.AddWithValue("@age", textBox5.Text);
                cmd.Parameters.AddWithValue("@problem", textBox6.Text);


                con.Open();
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    MessageBox.Show("Your Appoinment has been confirmed.");

                }
                else
                {
                    MessageBox.Show("Sorry! not confirmed :) ");
                }
                this.Hide();
                Form26 f26 = new Form26();
                f26.Show();

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form25 f25 = new Form25();
            f25.Show();
        }

        private void Form24_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
        }
    }
}
