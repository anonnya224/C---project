﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace Old_age_home_forms
{
    public partial class Form25 : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;
        public Form25()
        {
            InitializeComponent();
            BindGridView();
        }

        private void Form25_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
        }
        void BindGridView()
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "select NAME, Specialist_in,Appoinment_time,PICTURE FROM Doctor_Details; ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            DataTable data = new DataTable();
            sda.Fill(data);
            dataGridView1.DataSource = data;

            DataGridViewImageColumn dgv = new DataGridViewImageColumn();
            dgv = (DataGridViewImageColumn)dataGridView1.Columns[3];
            dgv.ImageLayout = DataGridViewImageCellLayout.Stretch;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.RowTemplate.Height = 80;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form26 f26 = new Form26();
            f26.Show();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Form24 f24 = new Form24();
            
            f24.textBox2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            f24.textBox3.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            f24.textBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            f24.pictureBox1.Image = GetPhoto((byte[])dataGridView1.SelectedRows[0].Cells[3].Value);
            this.Hide();
            f24.ShowDialog();
        }

        private Image GetPhoto(byte[] photo)
        {
            MemoryStream ms = new MemoryStream(photo);
            return Image.FromStream(ms);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
