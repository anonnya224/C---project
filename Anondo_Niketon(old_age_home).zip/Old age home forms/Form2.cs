﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;



namespace Old_age_home_forms
{
    public partial class Form2 : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "Insert into Donator_Details values (@Banking,@Username,@Address,@Contact_no,@Account_no,@Amount,@Card_no)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Banking", comboBox1.SelectedItem);
            cmd.Parameters.AddWithValue("@Username", textBox1.Text);
            cmd.Parameters.AddWithValue("@Address", textBox2.Text);
            cmd.Parameters.AddWithValue("@Contact_no", textBox3.Text);
            cmd.Parameters.AddWithValue("@Account_no", textBox4.Text);
            cmd.Parameters.AddWithValue("@Amount", textBox6.Text);
            //cmd.Parameters.AddWithValue("@Amount_no", textBox5.Text);
            cmd.Parameters.AddWithValue("@Card_no", textBox5.Text);

            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("Donated Successfully");
                ResetControl();
            }
            else
            {
                MessageBox.Show("Donation Failed");
            }
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }
        void ResetControl()
        {

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox1.SelectedItem = null;
            //textBox7.Clear();


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
           

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ResetControl();
        }
    }

    }


