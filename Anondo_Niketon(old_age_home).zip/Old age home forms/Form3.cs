﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Old_age_home_forms
{
    public partial class Form3 : Form
        
    {
        public static string user;
        public Form3()
            
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            {
                this.Hide();
                Form9 f9 = new Form9();
                f9.Show();
            }
        }


        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form12 f12 = new Form12();
            f12.Show();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form31 f31 = new Form31();
            f31.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
            label3.Text = Form13.user;
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form14 f14 = new Form14();
            f14.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form22 f22 = new Form22();
            f22.Show();
        }


        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 f10 = new Form10();
            f10.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form23 f23 = new Form23();
            f23.Show();
        }

    }
}
